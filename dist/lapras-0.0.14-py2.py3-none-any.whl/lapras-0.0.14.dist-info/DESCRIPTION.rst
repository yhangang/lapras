

# LAPRAS

[![PyPi version][pypi-image]][pypi-url]
[![Python version][python-image]][docs-url]




Lapras is developed to facilitate the dichotomy model development work.


## Install


via pip

```bash
pip install lapras
```

via source code

```bash
python setup.py install
```

## Usage

```python
lapras.IV("file_path")
```

## Documents

A simple API.

[pypi-image]: https://img.shields.io/badge/pypi-V0.0.10-%3Cgreen%3E
[pypi-url]: https://github.com/yhangang
[python-image]: https://img.shields.io/pypi/pyversions/toad.svg?style=flat-square





